-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 17 2024 г., 20:10
-- Версия сервера: 8.0.30
-- Версия PHP: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `english`
--

-- --------------------------------------------------------

--
-- Структура таблицы `courses`
--

CREATE TABLE `courses` (
  `id` int NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` decimal(10,2) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `courses`
--

INSERT INTO `courses` (`id`, `name`, `image`, `url`, `description`, `price`) VALUES
(1, 'Английский \nдля переговоров', 'img/1.png', 'course.php?id=1', 'Хотите восстановить в памяти основную теорию, которую знали раньше, но забыли, и снова заговорить на английском? Заполните пробелы \nна нашем курсе!', '750.00'),
(2, 'Английский для детей от 5 до 10 лет', 'img/2.png', 'course.php?id=2', 'Занятия проходят по уникальной методике, которая помогает детям заговорить на английском.', '830.00'),
(3, 'Разговорный английский \nдля начинающих \n(уровень A1)', 'img/3.png', 'course.php?id=3', 'Всего за 3 месяца вы начнете говорить на английском и сможете чувствовать себя уверенно в бытовых ситуациях в любой стране мира.', '800.00'),
(4, 'Английский \nдля IT-специалистов', 'img/4.png', 'course.php?id=4', 'Хотите повысить доход за счёт работы с зарубежными проектами? Наращивайте профессиональную лексику с нашими материалами про IT!', '800.00'),
(5, 'Курс для \nподготовки\nк TOEFL', 'img/5.png', 'course.php?id=5', 'Перестанете переживать за результат и разберёте все необходимые темы и форматы для успешной сдачи языкового экзамена.', '750.00'),
(6, 'Английский для подготовки к ЕГЭ', 'img/6.png', 'course.php?id=6', 'Системная подготовка к экзамену — залог высокого результата. Уделите внимание разговорной части ЕГЭ по английскому и сдайте его на максимум.', '700.00');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `course_id` int NOT NULL,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `course_id`, `order_date`) VALUES
(2, 14, 1, '2024-06-18 14:20:11'),
(3, 15, 3, '2024-06-18 14:28:56'),
(6, 16, 2, '2024-06-27 12:40:47'),
(7, 14, 5, '2024-06-27 13:18:03'),
(8, 15, 3, '2024-06-27 13:18:26'),
(9, 14, 2, '2024-10-17 15:33:33');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `admin` tinyint NOT NULL,
  `us_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` tinyint DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `admin`, `us_name`, `email`, `age`, `password`) VALUES
(14, 0, 'Илья', 'fghjk@mail.ru', 18, '$2y$10$n/WKFpzlNTDXNc.B6hC9u.OfA.LgMse53pbTUXvlF/iPuTfP24QLm'),
(15, 0, 'Даниил', 'ghjk@ghj', 22, '$2y$10$71HtoDXsw/pDTqRFVzX8F.LBWVagfQ/vjABoVr/rdAvxSBDcsyry6'),
(16, 0, 'Влад', 'fghjkddd@mail.ru', 25, '$2y$10$hPwgKxOHFdoExgNksHneVuP/XI1pQbOj/5SZ8hxlmfvLb10vOcbrS');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
