<?php
session_start();
include 'application/db.php';

if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['id'];
$courseId = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

if ($courseId > 0) {
    $query = "INSERT INTO orders (user_id, course_id) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $userId, $courseId);
    
    if ($stmt->execute()) {
        echo "Курс успешно добавлен!";
    } else {
        echo "Ошибка: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    header('Location: lk.php');
    exit();
} else {
    echo "Неверный идентификатор курса.";
    exit();
}
?>
