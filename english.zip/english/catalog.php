<?php
// Подключение к базе данных
include 'application/db.php';

$query = "SELECT * FROM courses";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ТалкТек</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
        .navbar {
            display: flex;
            justify-content: center;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand img {
            height: 50px;
        }
        .nav-link {
            color: #343a40;
            font-weight: 500;
            padding: 0 12px;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #007bff;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white">
    <a class="navbar-brand" href="index.php"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php" style="color: red !important;">Главная <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="catalog.php" style="color: red !important;">Курсы</a>
        </li>
        <li class="nav-item">
          <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
            }
          ?>
        </li>
      </ul>
    </div>
</nav>


  <section class="container mt-5">
    <h2 class="mb-4">Курсы</h2>
    <div class="row">
      <?php while ($row = $result->fetch_assoc()): ?>
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="<?php echo htmlspecialchars($row['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($row['name']); ?>">
          <div class="card-body">
            <h5 class="card-title"><?php echo htmlspecialchars($row['name']); ?></h5>
            <p class="card-text"><?php echo htmlspecialchars($row['description']); ?></p>
            <p class="card-text">Цена: <?php echo number_format($row['price'], 2, ',', ' '); ?> руб.</p>
            <a href="<?php echo htmlspecialchars($row['url']); ?>" class="btn btn-danger">Подробнее</a>
          </div>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </section>

  <footer class="bg-white text-white text-center py-4 mt-5" style="color: red !important;">
    &copy; 2024 ТалкТек. Все права защищены.
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
