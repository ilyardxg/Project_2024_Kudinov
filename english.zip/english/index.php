<?php
session_start();

include("application/db.php");

$result = mysqli_query($conn, "SELECT * FROM courses LIMIT 3");

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ТалкТек</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
        .navbar {
            display: flex;
            justify-content: center;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand img {
            height: 50px;
        }
        .nav-link {
            color: #343a40;
            font-weight: 500;
            padding: 0 12px;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #007bff;
        }
        .jumbotron {
            background-color: #faf0be;
           
           
            border-radius: 0;
        }
        .jumbotron h1 {
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .display-4{
          color: red;
        }
       
    </style>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white">
    <a class="navbar-brand" href="index.php"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php" style="color: red !important;">Главная <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="catalog.php" style="color: red !important;">Курсы</a>
        </li>
        <li class="nav-item">
          <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
            }
          ?>
        </li>
      </ul>
    </div>
</nav>


    <header class="jumbotron jumbotron-fluid">
        <div class="container text-center text-black">
            <h1 class="display-4">Добро пожаловать в интернет-магазин курсов английского!</h1>
            <p class="lead">Присоединяйтесь к нам для получения высококачественного образования и совершенствования ваших навыков английского языка. Наши опытные преподаватели гарантируют превосходное обучение, точную оценку ваших знаний и результативные методы обучения, чтобы вы всегда чувствовали себя уверенно в любых языковых ситуациях!</p>
        </div>
    </header>

  <section class="container mt-5">
    <h2 class="mb-4">Рекомендации</h2>
    <div class="row">
      <?php while($courses = mysqli_fetch_assoc($result)): ?>
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="<?php echo $courses['image']; ?>" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><?php echo $courses['name']; ?></h5>
            <p class="card-text"><?php echo $courses['description']; ?></p>
            <a href="<?php echo $courses['url']; ?>" class="btn btn-danger">Узнать больше</a>
          </div>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </section>

  <footer class="bg-white text-white text-center py-4 mt-5" style="color: red !important;">
    &copy; 2024 ТалкТек. Все права защищены.
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
